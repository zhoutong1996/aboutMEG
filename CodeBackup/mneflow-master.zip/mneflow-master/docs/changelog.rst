History
=======

0.2.0-beta (24-09-2020)
-----------------------
* updated API and documentation for compatibility with Tensorflow 2.0
* added Implementations of FBCSP-ShallowNet and Deep4
* added sorting components for interpretation by recursive elimination to LFCNN



0.1.1-beta (24-06-2019)
-----------------------
* massively updated API and examples. 
* added basic documentation.
* compatibility with previous version broken.


0.1.0-alpha (20-05-2019)
------------------------
* initial version
