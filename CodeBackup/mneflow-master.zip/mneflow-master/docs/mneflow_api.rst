MNEflow API
===========

mneflow.models.BaseModel class
******************************

.. autoclass:: mneflow.models.BaseModel
    :members:
    :undoc-members:
    :show-inheritance:

mneflow.Dataset
***************

.. autoclass:: mneflow.data.Dataset
    :members:
    :undoc-members:
    :show-inheritance:

mneflow.utils
*************

.. automodule:: mneflow.utils
    :members:
    :undoc-members:
    :show-inheritance:


mneflow.layers
**************

.. automodule:: mneflow.layers
    :members:
    :show-inheritance:



