Implemented models
******************

LFCNN
-----

.. autoclass:: mneflow.models.LFCNN
    :members:
    :undoc-members:
    :show-inheritance:

VARCNN
------

.. autoclass:: mneflow.models.VARCNN
    :members:
    :undoc-members:
    :show-inheritance:

EEGNet
------

.. autoclass:: mneflow.models.EEGNet
    :members:
    :undoc-members:
    :show-inheritance:

FBCSP_ShallowNet
----------------

.. autoclass:: mneflow.models.FBCSP_ShallowNet
    :members:
    :undoc-members:
    :show-inheritance:

Deep4
-----

.. autoclass:: mneflow.models.Deep4
    :members:
    :undoc-members:
    :show-inheritance:

