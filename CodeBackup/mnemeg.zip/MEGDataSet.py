import pickle
from glob import glob
import numpy as np
from torch.utils.data import Dataset
from sklearn.preprocessing import MinMaxScaler


# 定义一个数据集
class MEGDataset(Dataset):
    """ 数据集演示 """

    def __init__(self, data_dir, start_subject=0, subjects=10, sublists=[], reverse=True):
        """
        实现初始化方法，在初始化的时候将数据读载入
        :param data_dir:
        :param subjects:
        """
        self.data, self.labels, self.number = [], [], 0
        data_files = glob(data_dir + '*epochs.pkl')
        if not reverse:
            data_files.reverse()

        if start_subject > len(data_files):
            print('start_subject number {} > data_files number {}!'.format(start_subject, len(data_files)))
            return

        if start_subject + subjects > len(data_files):
            print('start_subject number {} + subjects number {} > data_files number {}!'.format(start_subject, subjects,
                                                                                                len(data_files)))
        data_files_number = min(start_subject + subjects, len(data_files))

        for i in range(start_subject, data_files_number):
            with open(data_files[i], 'rb') as f:
                meta = pickle.load(f)
                subject_data = meta['data']
                subject_labels = meta['labels']
                subject_number = meta['number']
                for j in range(subject_number):
                    self.data.append(subject_data[j])
                    self.labels.append(subject_labels[j])
                self.number += subject_number

        # 处理获取不同年龄段的数据时使用
        if len(sublists) > 0:
            for l in sublists:
                start_subject = l[0]
                subjects = l[1]
                if start_subject > len(data_files):
                    print('start_subject number {} > data_files number {}!'.format(start_subject, len(data_files)))
                    return

                if start_subject + subjects > len(data_files):
                    print('start_subject number {} + subjects number {} > data_files number {}!'.format(start_subject,
                                                                                                        subjects, len(
                            data_files)))
                data_files_number = min(start_subject + subjects, len(data_files))
                for i in range(start_subject, data_files_number):
                    with open(data_files[i], 'rb') as f:
                        meta = pickle.load(f)
                        subject_data = meta['data']
                        subject_labels = meta['labels']
                        subject_number = meta['number']
                        for j in range(subject_number):
                            self.data.append(subject_data[j])
                            self.labels.append(subject_labels[j])
                        self.number += subject_number

        assert len(self.data) == len(self.labels) == self.number

        minmax = MinMaxScaler(feature_range=(-1, 1))  # 数据归一化
        for sub in self.data:
            sub[0] = minmax.fit_transform(sub[0])
        self.data = np.array(self.data)
        self.labels = np.array(self.labels)
        self.data = self.data.astype(np.float32)  # 数据类型转换到float32，与torch默认类型一致，同时节约磁盘空间
        self.data = self.data.transpose([0, 1, 3, 2])  # 将时间维度和信道维度交换，信道维度作为最后一维
        self.labels = self.labels.astype(np.longlong)

        print(self.data.shape, self.labels.shape, self.number)

    def __len__(self):
        """
        返回df的长度
        :return:
        """
        return self.number

    def __getitem__(self, idx):
        """
        根据 idx 返回一行数据
        :param idx:
        :return:
        """
        return self.data[idx], self.labels[idx]  # data的时间维度和信道维度转置一下，将信道维度放在最后用于线性层转换
