import torch
import torch.nn as nn
import torch.nn.functional as F


class L1Penalty(torch.autograd.Function):
    """
    In the forward pass we receive a Tensor containing the input and return
    a Tensor containing the output. ctx is a context object that can be used
    to stash information for backward computation. You can cache arbitrary
    objects for use in the backward pass using the ctx.save_for_backward method.
    """

    @staticmethod
    def forward(ctx, input, l1weight):
        ctx.save_for_backward(input)
        ctx.l1weight = l1weight
        return input

    """
    In the backward pass we receive a Tensor containing the gradient of the loss
    with respect to the output, and we need to compute the gradient of the loss
    with respect to the input.
    """

    @staticmethod
    def backward(ctx, grad_output):
        input, = ctx.saved_tensors
        grad_input = input.clone().sign().mul(ctx.l1weight)
        grad_input += grad_output
        return grad_input, None


class LFCNN(nn.Module):
    def __init__(self):
        super().__init__()
        # batch*1*100*204（每次会送入batch个样本，增加维度1，时间节点数100, 输入信道数204）
        self.Spatial = nn.Linear(204, 32)
        # 下面的卷积层Conv2d的第一个参数指输入通道数，第二个参数指输出通道数，第三个参数指卷积核的大小
        self.Temporal = nn.Conv2d(1, 1, (7, 1), padding=(3, 0))  # 输入通道数1，输出通道数1，核的大小(7, 1)，填充(3, 0)
        # 下面的全连接层Linear的第一个参数指输入通道数，第二个参数指输出通道数
        self.fc1 = nn.Linear(1 * 50 * 32, 2)  # 输入通道数根据上一层卷积和池化决定，输出通道数是2，即2分类

    def forward(self, x):
        batch_size = x.size(0)  # batch*1*100*204
        # print(x.shape, batch_size)
        out = self.Spatial(x)  # ->batch*1*100*32
        # print(out.size())
        # out = L1Penalty.apply(out, 3e-4)
        # out = F.relu(out)
        # 无激活函数
        out = self.Temporal(out)
        # print(out.size())
        # out = L1Penalty.apply(out, 3e-4)
        out = F.relu(out)
        # print(out.size())
        out = F.max_pool2d(out, (2, 1), (2, 1))  # ->batch*1*100*32 时间维度上池化因子为2，步长为2
        # print(out.size())
        out = out.view(batch_size, -1)
        # print(out.size())
        out = self.fc1(out)  # ->batch*100
        # print(out.size())
        # out = L1Penalty.apply(out, 3e-4)
        out = F.dropout(out, 0.5)
        out = F.log_softmax(out, dim=1)  # 计算log(softmax(x))
        # print(out.size())
        return out
