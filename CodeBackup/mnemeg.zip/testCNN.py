import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset
from mnemeg.LFCNN import LFCNN
from mnemeg.MEGDataSet import MEGDataset
from mnemeg.VARCNN import VARCNN

# MEG epochs数据路径
data_dir = 'C:/MEG/freq0.0-45.0decim8/'
BATCH_SIZE = 1024
EPOCHS = 1000  # 总共训练批次
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")  # 让torch判断是否使用GPU，建议使用GPU环境，因为会快很多

train_dataset = MEGDataset(data_dir, 0, 200)
test_dataset = MEGDataset(data_dir, 0, 50, reverse=False)
# train_dataset = MEGDataset(data_dir, 0, 0, [[0, 50], [100, 50], [200, 50], [300, 50], [400, 50], [500, 50], [600, 50]])
# test_dataset = MEGDataset(data_dir, 0, 0, [[50, 10], [90, 10], [190, 10], [290, 10], [390, 10], [490, 10], [590, 10]])
train_loader = torch.utils.data.DataLoader(
    train_dataset, batch_size=BATCH_SIZE, shuffle=True)
test_loader = torch.utils.data.DataLoader(
    test_dataset, batch_size=BATCH_SIZE, shuffle=True)

# model = LFCNN().to(DEVICE)
model = VARCNN().to(DEVICE)
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=3e-4)


def train(model, device, train_loader, optimizer, epoch):
    model.train()
    loss = 0
    for batch_idx, (data, target) in enumerate(train_loader):
        data, target = data.to(device), target.to(device)
        optimizer.zero_grad()
        output = model(data)
        loss = criterion(output, target)
        loss.backward()
        optimizer.step()
        if (batch_idx + 1) % 5 == 0:
            print('Train Epoch: {} [{}/{} ({:.0f}%)]\tLoss: {:.6f}'.format(
                epoch, batch_idx * len(data), len(train_loader.dataset),
                       100. * batch_idx / len(train_loader), loss.item()))


def test(model, device, test_loader):
    model.eval()
    test_loss = 0
    correct = 0
    with torch.no_grad():
        for data, target in test_loader:
            data, target = data.to(device), target.to(device)
            data = data.float()
            output = model(data)
            test_loss += criterion(output, target).item()  # 将一批的损失相加
            pred = output.max(1, keepdim=True)[1]  # 找到概率最大的下标
            correct += pred.eq(target.view_as(pred)).sum().item()

    test_loss /= len(test_loader.dataset)
    print('Test set: Average loss: {:.4f}, Accuracy: {}/{} ({:.6f}%)\n'.format(
        test_loss, correct, len(test_loader.dataset),
        100. * correct / len(test_loader.dataset)))


for epoch in range(1, EPOCHS + 1):
    train(model, DEVICE, train_loader, optimizer, epoch)
    test(model, DEVICE, test_loader)
