# get epochs using your mne-python pipeline
import pickle
import random
import numpy as np
import mne
import traceback
from sklearn.preprocessing import MinMaxScaler

try:
    # GAN生成的epoch
    f = open('epoch/35600.pkl', 'rb')
    epochs_data = pickle.load(f)

    sample = open('C:/MEG/freq0.0-45.0decim8/sub-CC110033_120_epochs.pkl', 'rb')
    meta = pickle.load(sample)
    subject_data = meta['data']

    epochs_data = epochs_data.cpu()
    epochs_data = np.array(epochs_data)
    print(epochs_data)
    print(epochs_data.shape)
    epochs_data = epochs_data.transpose([0, 1, 3, 2])   # 信道维度恢复
    epochs_data = np.squeeze(epochs_data)
    minmax = MinMaxScaler(feature_range=(-1, 1))  # 数据逆归一化
    for i in range(len(subject_data)):
        minmax.fit_transform(np.squeeze(subject_data[0]))

    events = []
    for i in range(64):
        epochs_data[i] = minmax.inverse_transform(epochs_data[i])
        events.append([i, 0, random.randint(1, 2)])
    print(epochs_data)
    print(epochs_data.shape)
    ch_types = []
    ch_names = []
    for i in range(204):
        ch_types.append('grad')
        ch_names.append('MEG{}'.format(i+1))
    info = mne.create_info(
        ch_names=ch_names,
        ch_types=ch_types,
        sfreq=100)  # TODO：sfreq=125时epoch均被剔除
    events = np.array(events)
    event_id = {'1': 1, '2': 2}
    gan_epochs = mne.EpochsArray(epochs_data, info, tmin=-0.3)

    print(gan_epochs)
    # gan_epochs.plot_psd()
    gan_epochs.plot_image()
    gan_epochs.plot()
    # gan_epochs[0].plot_psd()
    gan_epochs[0].plot_image()
    gan_epochs[0].plot()

except IOError:
    print(IOError)
    traceback.print_exc()
except ValueError:
    print(ValueError)
    traceback.print_exc()
except KeyError:
    print(KeyError)
    traceback.print_exc()
except BaseException:
    print(BaseException)
    traceback.print_exc()
